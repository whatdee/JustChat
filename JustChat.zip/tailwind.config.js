module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        red: {
          500: '#E63946',
          700: '#B22234'
        },
        black: '#000000',
        white: '#FFFFFF',
        lightgrey: '#D3D3D3',
      },
    },
  },
  plugins: [],
};