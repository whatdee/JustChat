import React from 'react';

function App() {
  return (
    <div className="min-h-screen bg-lightgrey text-black flex flex-col items-center justify-center p-6">
      <h1 className="text-4xl font-bold text-red-700 mb-4">Just Chat</h1>
      <p className="text-lg">Coming soon... Stay tuned for the full hype!</p>
    </div>
  );
}

export default App;