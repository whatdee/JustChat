// Entry point for React
import React from 'react';
import ReactDOM from 'react-dom/client';
